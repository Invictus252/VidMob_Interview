package com.company;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


public class CalculatorTest {

    @Test
    public void testWorkingCases() throws Exception{
        String equation1 = "1 + 2";
        double ans1 = 3.0;
        Calculator c1 = new Calculator(equation1);
        Assert.assertThat(c1.processEquation(), CoreMatchers.is(ans1));

        String equation2 = "4*5/2";
        double ans2 = 10.0;
        Calculator c2 = new Calculator(equation2);
        Assert.assertThat(c2.processEquation(), CoreMatchers.is(ans2));

        String equation3 = "-.32       /.5";
        double ans3 = -0.64;
        Calculator c3 = new Calculator(equation3);
        Assert.assertThat(c3.processEquation(), CoreMatchers.is(ans3));

        String equation4 = "(4-2)*3.5";
        double ans4 = 7.0;
        Calculator c4 = new Calculator(equation4);
        Assert.assertThat(c4.processEquation(), CoreMatchers.is(ans4));

        String equation5 = "6-(5-3)+10";
        double ans5 = 14.0;
        Calculator c5 = new Calculator(equation5);
        Assert.assertThat(c5.processEquation(), CoreMatchers.is(ans5));

    }

    @Test
    public void testErrorCases() throws Exception{
        try {
            Calculator c1 = new Calculator("19 + cinnamon");
            c1.processEquation();
            fail("Should have thrown an exception");
        } catch (final RuntimeException e) {
            assertTrue(true);
        }

        try {
            Calculator c1 = new Calculator("2+-+-4");
            c1.processEquation();
            fail("Should have thrown an exception");
        } catch (final RuntimeException e) {
            assertTrue(true);
        }

        try {
            Calculator c1 = new Calculator("((1 +1)");
            c1.processEquation();
            fail("Should have thrown an exception");
        } catch (final RuntimeException e) {
            assertTrue(true);
        }


    }
}